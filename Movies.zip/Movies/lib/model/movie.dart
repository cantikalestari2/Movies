class Movie{
  final String id;
  final String title;
  final String imageUrl;
  final String description;
  final String rating;
  final String year;
  final String duration;

  Movie({
    this.id,
    this.title,
    this.imageUrl,
    this.description,
    this.rating,
    this.year,
    this.duration,
  });
}

final movieList = [
  Movie(
    id: 'tt4154796',
    title: 'Danur 2: Maddah',
    imageUrl: 'https://m.media-amazon.com/images/M/MV5BZTgwZWFkMTEtNmIxYi00NDg1LTg2ZDEtYzljZGQ5NDBmNzY2XkEyXkFqcGdeQXVyNjI3MDYxMjg@._V1_.jpg',
    description: 'Risa, remaja perempuan yang memiliki 3 sahabat hantu bernama Peter, William, dan Janshen. Risa kini tinggal bersama adiknya Riri, yang sudah mulai jengah dengan kemampuan Risa bisa melihat hantu. Apalagi mereka untuk sementara hanya tinggal berdua karena ibunya menemani bapaknya dinas di luar negeri. Keluarga pamannya, Om Ahmad baru pindah ke Bandung bersama istrinya, Tante Tina dan Angki anaknya. Risa dan Riri sering berkunjung bahkan menginap di rumah Om Ahmad dan Tante Tina. Risa awalnya tidak merasa ada yang aneh dengan rumah Om Ahmad, namun suatu hari Risa memergoki Om Ahmad pergi bersama seorang wanita, Risa hampir tidak percaya bahwa Omnya selingkuh, Risa tidak berani bilang ke Tante Tina dan memilih menyelidiki sendiri. Namun, setelah itu Angki bercerita beberapa hal janggal terjadi dan yang paling aneh adalah sikap Om Ahmad berubah. Suatu malam Risa diganggu oleh sosok hantu perempuan menyeramkan di rumah itu. Apakah benar Om Ahmad selingkuh? Apa hubungannya dengan teror hantu wanita di rumah itu yang mengganggu keluarga Om Ahmad termasuk Risa? Apakah Peter dan kawan-kawan akan datang membantu Risa, meskipun Peter memperingatkan Risa sebelumnya tentang roh jahat berbahaya di rumah Om Ahmad itu?',
    rating: '8.6',
    year: '2018',
    duration: '90 min'
  ),
  Movie(
    id: 'tt7286456',
    title: 'Dua Garis Biru',
    imageUrl: 'https://cdn.cgv.id/uploads/movie/compressed/19019800.jpg',
    description: 'Bima dan Dara adalah sepasang kekasih yang masih duduk di bangku SMA. Pada usia 17 tahun, mereka nekat bersanggama di luar nikah. Dara pun hamil. Keduanya kemudian dihadapkan pada kehidupan yang tak terbayangkan bagi anak seusia mereka, kehidupan sebagai orangtua.',
    rating: '9.1',
    year: '2019',
    duration: '113 min'
  ),
  Movie(
    id: 'tt9248972',
    title: 'After Met You',
    imageUrl: 'https://web3.21cineplex.com/movie-images/09AMYU.jpg',
    description: 'Ari, cowo terkeren dan tertampan di sekolahnya yang ditantang taruhan oleh teman segenknya, THE DAKS untuk mencari pacar yang sudah pasti tidak tertarik sama Ari. Ara, gadis introvert dan pintar di sekolah pun jadi sasaran Ari...',
    rating: '6.6',
    year: '2019',
    duration: '107 min'
  ),
  Movie(
    id: 'tt7349950',
    title: 'Yowis Ben',
    imageUrl: 'https://upload.wikimedia.org/wikipedia/id/thumb/2/2e/Yowis_Ben.jpg/416px-Yowis_Ben.jpg',
    description: 'Bayu menyukai Susan sejak lama, namun merasa minder dengan keadaan dirinya yang pas-pasan. Bayu bertekad mengubah dirinya menjadi lebih populer dari Roy, pacar Susan yang gitaris band. Ia membentuk band bersama teman-temannya, yang dinamai Yowis Ben. Langkah Bayu dan teman-temannya tidak mudah. Terjadi perpecahan antar personil band. Berhasilkah Bayu mempertahankan band-nya dan mendapatkan Susan?',
    rating: '7.0',
    year: '2018',
    duration: '169 min'
  ),
  Movie(
    id: 'tt6806448',
    title: 'Cek Toko Sebelah',
    imageUrl: 'https://upload.wikimedia.org/wikipedia/id/thumb/2/20/Cek_Toko_Sebelah.jpg/480px-Cek_Toko_Sebelah.jpg',
    description: 'Setelah Erwin menerima tawaran kerja di Singapura, ayahnya sakit dan butuh dirinya untuk meneruskan usaha toko. Sementara Yohan, kakaknya yang kurang bertanggung jawab, merasa ayahnya pilih kasih.',
    rating: '6.7',
    year: '2016',
    duration: '137 min'
  ),
  Movie(
    id: 'tt6105098',
    title: 'Critical Eleven',
    imageUrl: 'https://cdn.gramedia.com/uploads/items/9786020346403_critical-eleven-cover-baru__w600_hauto.jpg',
    description: 'Ale jatuh hati kepada Anya setelah bertemu di pesawat dalam perjalanan ke Sydney. Namun, percikan cinta mereka perlahan memudar setelah Anya keguguran, dan mengalami banyak masalah lainnya.',
    rating: '7.1',
    year: '2017',
    duration: '118 min'
  ),
];

final topRatedMovieList = [
  Movie(
    id: 'tt1375666',
    title: 'Inception',
    imageUrl: 'https://m.media-amazon.com/images/M/MV5BMjAxMzY3NjcxNF5BMl5BanBnXkFtZTcwNTI5OTM0Mw@@._V1_SX300.jpg',
    description: 'A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O.',
    rating: '8.8',
    year: '2010',
    duration: '148 min'
  ),
  Movie(
    id: 'tt0468569',
    title: 'The Dark Knight',
    imageUrl: 'https://m.media-amazon.com/images/M/MV5BMTMxNTMwODM0NF5BMl5BanBnXkFtZTcwODAyMTk2Mw@@._V1_SX300.jpg',
    description: 'When the menace known as The Joker emerges from his mysterious past, he wreaks havoc and chaos on the people of Gotham. The Dark Knight must accept one of the greatest psychological and physical tests of his ability to fight injustice.',
    rating: '9.0',
    year: '2008',
    duration: '152 min'
  ),
  Movie(
    id: 'tt0816692',
    title: 'Interstellar',
    imageUrl: 'https://m.media-amazon.com/images/M/MV5BZjdkOTU3MDktN2IxOS00OGEyLWFmMjktY2FiMmZkNWIyODZiXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg',
    description: 'A team of explorers travel through a wormhole in space in an attempt to ensure humanity\'s survival.',
    rating: '8.6',
    year: '2014',
    duration: '169 min'
  ),
  Movie(
    id: 'tt4633694',
    title: 'Spider-Man: Into the Spider-Verse',
    imageUrl: 'https://m.media-amazon.com/images/M/MV5BMjMwNDkxMTgzOF5BMl5BanBnXkFtZTgwNTkwNTQ3NjM@._V1_SX300.jpg',
    description: 'Teen Miles Morales becomes Spider-Man of his reality, crossing his path with five counterparts from other dimensions to stop a threat for all realities.',
    rating: '8.4',
    year: '2018',
    duration: '117 min'
  ),
  Movie(
    id: 'tt1187043',
    title: '3 Idiots',
    imageUrl: 'https://m.media-amazon.com/images/M/MV5BNTkyOGVjMGEtNmQzZi00NzFlLTlhOWQtODYyMDc2ZGJmYzFhXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_SX300.jpg',
    description: 'Two friends are searching for their long lost companion. They revisit their college days and recall the memories of their friend who inspired them to think differently, even as the rest of the world called them \"idiots\".',
    rating: '8.4',
    year: '2009',
    duration: '170 min'
  ),
  Movie(
    id: 'tt1049413',
    title: 'Up',
    imageUrl: 'https://m.media-amazon.com/images/M/MV5BMTk3NDE2NzI4NF5BMl5BanBnXkFtZTgwNzE1MzEyMTE@._V1_SX300.jpg',
    description: 'Seventy-eight year old Carl Fredricksen travels to Paradise Falls in his home equipped with balloons, inadvertently taking a young stowaway.',
    rating: '8.2',
    year: '2009',
    duration: '96 min'
  ),
];

final bestMovieList = [
  Movie(
    id: 'tt0437086',
    title: 'Avengers: Endgame',
    imageUrl: 'https://cdn.cgv.id/uploads/movie/compressed/19022300.jpg',
    description: 'Melanjutkan Avengers Infinity War, dimana kejadian setelah Thanos berhasil mendapatkan semua infinity stones.',
    rating: '9.2',
    year: '2019',
    duration: '182 min'
  ),
  Movie(
    id: 'tt6320628',
    title: 'Parasite',
    imageUrl: 'https://cdn.cgv.id/uploads/movie/compressed/19019400.jpg',
    description: 'Keluarga Ki-taek beranggotakan empat orang pengangguran dengan masa depan suram menanti mereka.',
    rating: '8.1',
    year: '2019',
    duration: '129 min'
  ),
  Movie(
    id: 'tt1979376',
    title: 'Joker',
    imageUrl: 'https://cdn.cgv.id/uploads/movie/compressed/19029600.jpg',
    description: 'Joker merupakan film bergenre psikologi karya sutradara Todd Phillips. Kisah cenderung gelap dan muram dan dinilai dapat memengaruhi psikologi.',
    rating: '8.1',
    year: '2019',
    duration: '100 min'
  ),
];

final allMoviesList = [
  Movie(
    id: 'tt0437086',
    title: 'Alita: Battle Angel',
    imageUrl: 'https://m.media-amazon.com/images/M/MV5BNzVhMjcxYjYtOTVhOS00MzQ1LWFiNTAtZmY2ZmJjNjIxMjllXkEyXkFqcGdeQXVyNTc5OTMwOTQ@._V1_SX300.jpg',
    description: 'A deactivated cyborg is revived, but cannot remember anything of her past life and goes on a quest to find out who she is.',
    rating: '7.4',
    year: '2019',
    duration: '122 min'
  ),
  Movie(
    id: 'tt6320628',
    title: 'Spider-Man: Far from Home',
    imageUrl: 'https://m.media-amazon.com/images/M/MV5BMGZlNTY1ZWUtYTMzNC00ZjUyLWE0MjQtMTMxN2E3ODYxMWVmXkEyXkFqcGdeQXVyMDM2NDM2MQ@@._V1_SX300.jpg',
    description: 'Following the events of Avengers: Endgame (2019), Spider-Man must step up to take on new threats in a world that has changed forever.',
    rating: '7.7',
    year: '2019',
    duration: '129 min'
  ),
  Movie(
    id: 'tt1979376',
    title: 'Toy Story 4',
    imageUrl: 'https://m.media-amazon.com/images/M/MV5BMTYzMDM4NzkxOV5BMl5BanBnXkFtZTgwNzM1Mzg2NzM@._V1_SX300.jpg',
    description: 'When a new toy called \"Forky\" joins Woody and the gang, a road trip alongside old and new friends reveals how big the world can be for a toy.',
    rating: '8.1',
    year: '2019',
    duration: '100 min'
  ),
];

import 'package:flutter/material.dart';
import 'dart:convert';



class LocaljsonScreen extends StatelessWidget {
  static const String routeName = "/localjson";


    List data;
//yang wajib include, yang ga wajib extends
  @override 
  Widget build(BuildContext context) {



     return Scaffold(
        appBar: AppBar(
          title: Text("Load local JSON file"),
        ),
        body: Container(
          child: Center(
            // Use future builder and DefaultAssetBundle to load the local JSON file
            child: FutureBuilder(
                future: DefaultAssetBundle
                    .of(context)
                    .loadString('data_repo/starwars_data.json'),
                builder: (context, snapshot) {
                  // Decode the JSON
                  var new_data = json.decode(snapshot.data.toString());

                  return ListView.builder(
                    // Build the ListView
                    itemBuilder: (BuildContext context, int index) {
                      return Card(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: <Widget>[
                            Text("Judul: " + new_data[index]['judul']),
                            Text("Genre: " + new_data[index]['genre']),
                            Text("Rating: " + new_data[index]['rating']),
                            Text(
                                "Durasi: " + new_data[index]['durasi']),
                            Text(
                                "Tahun: " + new_data[index]['tahun']),
                          ],
                        ),
                      );
                    },
                    itemCount: new_data == null ? 0 : new_data.length,
                  );
                }),
          ),
        ));


  
  
  
  
  
  
  
  }
}
import 'package:flutter/material.dart';
import './screens/movie_details_screen.dart';
import 'package:hello1/screens/settings.dart';
import 'package:hello1/screens/account.dart';
import './screens/home.dart';
import 'package:hello1/screens/localjson.dart';
import 'package:hello1/screens/http.dart';

void main(){
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: HomeScreen(), // kalau () kosong berarti boleh NULL, kalau (BuildContext=1) berarti tdk blh NULL
    routes: <String, WidgetBuilder>{
      MovieDetailsScreen.routeName: (ctx) => MovieDetailsScreen(),
      SettingsScreen.routeName: (BuildContext context) => SettingsScreen(), //parameter wajib isi
      AccountScreen.routeName: (BuildContext context) => AccountScreen(),
      LocaljsonScreen.routeName: (BuildContext context) => LocaljsonScreen(),
      HttpScreen.routeName: (BuildContext context) => HttpScreen(),
    },
  ));
}